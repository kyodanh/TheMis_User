/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("adfs=1; DOMAIN=themis.test.xplat.fpt.com.vn");

	web_add_cookie("sstk=b2c6ea5e-3e75-4a43-a789-45728ab41ed6-1616408338537; DOMAIN=themis.test.xplat.fpt.com.vn");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_cookie("921003f142e7cfc42fd106350b5b3d9e=6ef5a8f4485d2a17e81198c877602733; DOMAIN=themis.test.xplat.fpt.com.vn");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_url("dang-nhap-test-perf", 
		"URL=https://themis.test.xplat.fpt.com.vn/dang-nhap-test-perf", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/image/avatar.jpg", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/common.css", ENDITEM, 
		"Url=/assets/new/webfonts/fa-solid-900.woff2", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/all.css", ENDITEM, 
		"Url=/assets/new/image/background.jpg", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/newstyle/login.css", ENDITEM, 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	lr_start_transaction("login");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(4);

	web_custom_request("dang-nhap-demo", 
		"URL=https://themis.test.xplat.fpt.com.vn/dang-nhap-demo", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/dang-nhap-test-perf", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"user\":\"danhnc14\"}", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("bao-cao-nhan-vien", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-nhan-vien", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://themis.test.xplat.fpt.com.vn/dang-nhap-test-perf", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/assets/new/image/topBannerBackground.png", ENDITEM, 
		"Url=/assets/new/webfonts/fa-solid-900.woff2", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/all.css", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(11);

	web_custom_request("bao-cao-nhan-vien_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-khoan/bao-cao-nhan-vien", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/bao-cao-nhan-vien", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"searchString\":\"\",\"limit\":10,\"pageNum\":1,\"advance\":{\"thongTinNam\":\"2021\",\"thongTinKyTinh\":\"5\",\"loaiTinh\":\"san-xuat\",\"sort\":{\"sortSanXuat\":[],\"sortKinhDoanhNT\":[],\"sortKinhDoanhNN\":[]}}}", 
		LAST);

	web_custom_request("check-eva", 
		"URL=https://themis.test.xplat.fpt.com.vn/data-rmis/check-eva", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/bao-cao-nhan-vien", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"searchString\":\"\",\"limit\":10,\"pageNum\":1,\"advance\":{\"thongTinNam\":\"2021\",\"thongTinKyTinh\":\"\",\"loaiTinh\":\"san-xuat\",\"sort\":{\"sortSanXuat\":[],\"sortKinhDoanhNT\":[],\"sortKinhDoanhNN\":[]}}}", 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	return 0;
}
