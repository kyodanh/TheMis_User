Action()
{

	lr_start_transaction("Trans_Thongtincanhan");

	lr_start_transaction("Trans_KinhDoanh");

	web_add_auto_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_custom_request("bao-cao-nhan-vien_3", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-khoan/bao-cao-nhan-vien", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/bao-cao-nhan-vien", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"searchString\":\"\",\"limit\":10,\"pageNum\":1,\"advance\":{\"thongTinNam\":\"2021\",\"thongTinKyTinh\":\"5\",\"loaiTinh\":\"kinh-doanh\",\"sort\":{\"sortSanXuat\":[],\"sortKinhDoanhNT\":[],\"sortKinhDoanhNN\":[]}}}", 
		LAST);

	lr_end_transaction("Trans_KinhDoanh",LR_AUTO);

	lr_start_transaction("Trans_SanXuat");

	web_custom_request("bao-cao-nhan-vien_4", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-khoan/bao-cao-nhan-vien", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/bao-cao-nhan-vien", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"searchString\":\"\",\"limit\":10,\"pageNum\":1,\"advance\":{\"thongTinNam\":\"2021\",\"thongTinKyTinh\":\"5\",\"loaiTinh\":\"san-xuat\",\"sort\":{\"sortSanXuat\":[],\"sortKinhDoanhNT\":[],\"sortKinhDoanhNN\":[]}}}", 
		LAST);

	lr_end_transaction("Trans_SanXuat",LR_AUTO);

	lr_end_transaction("Trans_Thongtincanhan",LR_AUTO);

	lr_start_transaction("Trans_Baocao");

	lr_start_transaction("Trans_DashBoard");

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(5);

	web_url("bao-cao-lanh-dao", 
		"URL=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://themis.test.xplat.fpt.com.vn/bao-cao-nhan-vien", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/new/image/topBannerBackground.png", ENDITEM, 
		"Url=../assets/new/image/topBannerFptLogoRetracted2.png", ENDITEM, 
		"Url=../assets/new/webfonts/fa-solid-900.woff2", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/all.css", ENDITEM, 
		"Url=../assets/image/version2/noData.png", ENDITEM, 
		LAST);

	web_add_auto_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("get-don-vi-bo-phan", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-kinh-doanh/get-don-vi-bo-phan", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("get-thong-tin-FIS", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-FIS", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[],\"thongTinDonViText\":[],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":null}", 
		LAST);

	web_custom_request("get-thong-tin-don-vi-lnbase", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-don-vi-lnbase", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\"],\"thongTinDonViText\":[\"FIS\"],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":null,\"thongTinNam\":\"2021\"}", 
		LAST);

	web_custom_request("get-thong-tin-don-vi", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-don-vi", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\"],\"thongTinDonViText\":[\"FIS\"],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":null}", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_add_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("get-thong-tin-don-vi-kd-da", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-don-vi-kd-da", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\"],\"thongTinDonViText\":[],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":null}", 
		LAST);

	web_url("2021", 
		"URL=https://themis.test.xplat.fpt.com.vn/thong-tin/ky-tinh-khoan-theo-nam-select/2021", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_custom_request("get-thong-tin-FIS_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-FIS", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\",\"0\"],\"thongTinDonViText\":[\"FIS\",\"FIS\"],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":\"5\"}", 
		LAST);

	web_custom_request("get-thong-tin-don-vi-lnbase_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-don-vi-lnbase", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\"],\"thongTinDonViText\":[\"FIS\"],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":\"5\",\"thongTinNam\":\"2021\"}", 
		LAST);

	web_custom_request("get-thong-tin-don-vi-kd-da_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-don-vi-kd-da", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\"],\"thongTinDonViText\":[],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":\"5\"}", 
		LAST);

	web_custom_request("get-thong-tin-don-vi_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-don-vi/get-thong-tin-don-vi", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"0\"],\"thongTinDonViText\":[\"FIS\"],\"thongTinBoPhan\":[],\"thongTinKyKhoan\":\"5\"}", 
		LAST);

	lr_end_transaction("Trans_DashBoard",LR_AUTO);

	lr_start_transaction("Trans_K_khoan");

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("bcld-kkhoan", 
		"URL=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kkhoan", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bao-cao-lanh-dao", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/new/image/topBannerBackground.png", ENDITEM, 
		"Url=../assets/new/webfonts/fa-solid-900.woff2", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/all.css", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("get-don-vi-bo-phan_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-kinh-doanh/get-don-vi-bo-phan", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kkhoan", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("tim-kiem-bcld", 
		"URL=https://themis.test.xplat.fpt.com.vn/bang-khoan-san-xuat/tim-kiem-bcld", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kkhoan", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"searchString\":\"\",\"limit\":10,\"pageNum\":1,\"advance\":{\"listFis\":[\"FIS BANK\",\"FIS CA\",\"FIS ENT\",\"FIS ERP\",\"FIS ERPHCM\",\"FIS FPS\",\"FIS FSB\",\"FIS FTS\",\"FIS GMC\",\"FIS OBC\",\"FIS SRV\"],\"bangKhoan\":\"BCLD_DA\",\"fisX\":\"0\",\"ttbp\":\"0\",\"namTinhKhoan\":\"2021\",\"typeSort\":\"\",\"valueSort\":\"\"}}", 
		LAST);

	web_add_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("tim-kiem-bcld_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/bang-khoan-kinh-doanh/tim-kiem-bcld", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kkhoan", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"BodyBinary={\"searchString\":\"\",\"limit\":10,\"pageNum\":1,\"advance\":{\"listFis\":[\"FIS BANK\",\"FIS CA\",\"FIS ENT\",\"FIS ERP\",\"FIS ERPHCM\",\"FIS FPS\",\"FIS FSB\",\"FIS FTS\",\"FIS GMC\",\"FIS OBC\",\"FIS SRV\"],\"bangKhoan\":\"BCLD_KD\",\"fisX\":\"0\",\"ttbp\":\"T\\xE1\\xBA\\xA5t C\\xE1\\xBA\\xA3\",\"namTinhKhoan\":\"2021\",\"typeSort\":\"\",\"valueSort\":\"\"}}", 
		LAST);

	lr_end_transaction("Trans_K_khoan",LR_AUTO);

	lr_start_transaction("Trans_KinhDoanh");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("bcld-kinh-doanh", 
		"URL=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kinh-doanh", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kkhoan", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/new/image/topBannerBackground.png", ENDITEM, 
		"Url=../assets/new/webfonts/fa-solid-900.woff2", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/all.css", ENDITEM, 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("2021_2", 
		"URL=https://themis.test.xplat.fpt.com.vn/thong-tin/ky-tinh-khoan-theo-nam-select/2021", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kinh-doanh", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Site");

	web_revert_auto_header("sec-ch-ua");

	web_revert_auto_header("sec-ch-ua-mobile");

	web_url("livetile", 
		"URL=https://cdn.onenote.net/livetile/?Language=en-US", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Trans_KinhDoanh",LR_AUTO);

	lr_start_transaction("Trans_DuAn");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	lr_think_time(5);

	web_url("bcld-du-an", 
		"URL=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-du-an", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-kinh-doanh", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../assets/new/image/topBannerBackground.png", ENDITEM, 
		"Url=../assets/new/webfonts/fa-solid-900.woff2", "Referer=https://themis.test.xplat.fpt.com.vn/assets/new/css/all.css", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Origin", 
		"https://themis.test.xplat.fpt.com.vn");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("get-don-vi-bo-phan_3", 
		"URL=https://themis.test.xplat.fpt.com.vn/bcld-kinh-doanh/get-don-vi-bo-phan", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-du-an", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_custom_request("du-an", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-lanh-dao-DA/du-an", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-du-an", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"BodyBinary={\"thongTinDonVi\":[\"715\",\"713\",\"770\",\"744\",\"756\",\"778\",\"732\",\"741\",\"763\",\"760\",\"699\"],\"listBP\":[{\"thongTinBoPhan\":\"716\",\"thongTinBoPhanText\":\"AB BNKSAL5\"},{\"thongTinBoPhan\":\"717\",\"thongTinBoPhanText\":\"PrB BNKVCB\"},{\"thongTinBoPhan\":\"718\",\"thongTinBoPhanText\":\"PB BNKFIN\"},{\"thongTinBoPhan\":\"719\",\"thongTinBoPhanText\":\"BOM BNK HN\"},{\"thongTinBoPhan\":\"720\",\"thongTinBoPhanText\":\"PrBBNKBIDV\"},{\"thongTinBoPhan\":\"721\",\""
		"thongTinBoPhanText\":\"AB BNK HCM\"},{\"thongTinBoPhan\":\"722\",\"thongTinBoPhanText\":\"BO BNK HCM\"},{\"thongTinBoPhan\":\"723\",\"thongTinBoPhanText\":\"AB BNKSAL1\"},{\"thongTinBoPhan\":\"724\",\"thongTinBoPhanText\":\"PB BNKDATA\"},{\"thongTinBoPhan\":\"725\",\"thongTinBoPhanText\":\"AB BNKSAL2\"},{\"thongTinBoPhan\":\"727\",\"thongTinBoPhanText\":\"AB BNK CON\"},{\"thongTinBoPhan\":\"728\",\"thongTinBoPhanText\":\"BO BNK HN\"},{\"thongTinBoPhan\":\"729\",\"thongTinBoPhanText\":\"PB BNKPAY\""
		"},{\"thongTinBoPhan\":\"731\",\"thongTinBoPhanText\":\"PrBBNKMPU\"},{\"thongTinBoPhan\":\"823\",\"thongTinBoPhanText\":\"PrBBNKSG31\"},{\"thongTinBoPhan\":\"10911\",\"thongTinBoPhanText\":\"AB BNKSAL3\"},{\"thongTinBoPhan\":\"10986\",\"thongTinBoPhanText\":\"PB BNK PMO\"},{\"thongTinBoPhan\":\"10987\",\"thongTinBoPhanText\":\"Back Office + BOM\"},{\"thongTinBoPhan\":\"10991\",\"thongTinBoPhanText\":\"AB BNK HCM\"},{\"thongTinBoPhan\":\"10992\",\"thongTinBoPhanText\":\"AB BNKSAL3\"},{\""
		"thongTinBoPhan\":\"11016\",\"thongTinBoPhanText\":\"BANK TECSOL BS3\"},{\"thongTinBoPhan\":\"11017\",\"thongTinBoPhanText\":\"BANK SOF HCM\"},{\"thongTinBoPhan\":\"714\",\"thongTinBoPhanText\":\"AB CA HN\"},{\"thongTinBoPhan\":\"771\",\"thongTinBoPhanText\":\"AB ENT ESC\"},{\"thongTinBoPhan\":\"772\",\"thongTinBoPhanText\":\"BOM ENT\"},{\"thongTinBoPhan\":\"773\",\"thongTinBoPhanText\":\"BO ENT\"},{\"thongTinBoPhan\":\"774\",\"thongTinBoPhanText\":\"AB ENT GSC\"},{\"thongTinBoPhan\":\"775\",\""
		"thongTinBoPhanText\":\"AB ENT DSC\"},{\"thongTinBoPhan\":\"776\",\"thongTinBoPhanText\":\"PB ENT TSC\"},{\"thongTinBoPhan\":\"777\",\"thongTinBoPhanText\":\"PrB ENTSSC\"},{\"thongTinBoPhan\":\"10927\",\"thongTinBoPhanText\":\"Back Office + BOM\"},{\"thongTinBoPhan\":\"745\",\"thongTinBoPhanText\":\"BOM ERP HN\"},{\"thongTinBoPhan\":\"746\",\"thongTinBoPhanText\":\"PB ERP ORC\"},{\"thongTinBoPhan\":\"747\",\"thongTinBoPhanText\":\"TH ERP\"},{\"thongTinBoPhan\":\"748\",\"thongTinBoPhanText\":\"AB "
		"ERP PUB\"},{\"thongTinBoPhan\":\"749\",\"thongTinBoPhanText\":\"ABERPPetro\"},{\"thongTinBoPhan\":\"750\",\"thongTinBoPhanText\":\"PBERP TECH\"},{\"thongTinBoPhan\":\"751\",\"thongTinBoPhanText\":\"PB ERP SAP\"},{\"thongTinBoPhan\":\"752\",\"thongTinBoPhanText\":\"PB ERP HCM\"},{\"thongTinBoPhan\":\"753\",\"thongTinBoPhanText\":\"PB ERP MBY\"},{\"thongTinBoPhan\":\"754\",\"thongTinBoPhanText\":\"AB ERP PRI\"},{\"thongTinBoPhan\":\"755\",\"thongTinBoPhanText\":\"ERPHCM\"},{\"thongTinBoPhan\":\"812"
		"\",\"thongTinBoPhanText\":\"Back Office + BOM\"},{\"thongTinBoPhan\":\"10993\",\"thongTinBoPhanText\":\"ERP SAP 01\"},{\"thongTinBoPhan\":\"10994\",\"thongTinBoPhanText\":\"ERP SAP 02\"},{\"thongTinBoPhan\":\"10995\",\"thongTinBoPhanText\":\"ERPHCM ORC\"},{\"thongTinBoPhan\":\"10996\",\"thongTinBoPhanText\":\"ERPHCM SAP\"},{\"thongTinBoPhan\":\"10997\",\"thongTinBoPhanText\":\"ERPMBYIMPL\"},{\"thongTinBoPhan\":\"10998\",\"thongTinBoPhanText\":\"ERPMBYSALE\"},{\"thongTinBoPhan\":\"10999\",\""
		"thongTinBoPhanText\":\"ERPORCBANK\"},{\"thongTinBoPhan\":\"11000\",\"thongTinBoPhanText\":\"ERPORCPUB\"},{\"thongTinBoPhan\":\"11001\",\"thongTinBoPhanText\":\"ERPPETROIM\"},{\"thongTinBoPhan\":\"11002\",\"thongTinBoPhanText\":\"ERPPETROSL\"},{\"thongTinBoPhan\":\"11003\",\"thongTinBoPhanText\":\"ERPSAPGLB\"},{\"thongTinBoPhan\":\"11004\",\"thongTinBoPhanText\":\"ERPTECHORC\"},{\"thongTinBoPhan\":\"11005\",\"thongTinBoPhanText\":\"ERPTECHSMB\"},{\"thongTinBoPhan\":\"11006\",\"thongTinBoPhanText\""
		":\"ERPTECHTEC\"},{\"thongTinBoPhan\":\"11007\",\"thongTinBoPhanText\":\"ERPTECHSUP\"},{\"thongTinBoPhan\":\"11008\",\"thongTinBoPhanText\":\"ERPTECHSAP\"},{\"thongTinBoPhan\":\"11014\",\"thongTinBoPhanText\":\"ERP PUBLIC\"},{\"thongTinBoPhan\":\"11015\",\"thongTinBoPhanText\":\"ERP GIS&EMS\"},{\"thongTinBoPhan\":\"11018\",\"thongTinBoPhanText\":\"ABERP Ener\"},{\"thongTinBoPhan\":\"801\",\"thongTinBoPhanText\":\"ERPHCM\"},{\"thongTinBoPhan\":\"10913\",\"thongTinBoPhanText\":\"ERPHCM\"},{\""
		"thongTinBoPhan\":\"10943\",\"thongTinBoPhanText\":\"ERPHCM\"},{\"thongTinBoPhan\":\"10970\",\"thongTinBoPhanText\":\"AB ERP HCM\"},{\"thongTinBoPhan\":\"10971\",\"thongTinBoPhanText\":\"BOM ERPHCM\"},{\"thongTinBoPhan\":\"10972\",\"thongTinBoPhanText\":\"BO ERP HCM\"},{\"thongTinBoPhan\":\"779\",\"thongTinBoPhanText\":\"FPSPRESALE\"},{\"thongTinBoPhan\":\"780\",\"thongTinBoPhanText\":\"BOM FPS HN\"},{\"thongTinBoPhan\":\"781\",\"thongTinBoPhanText\":\"AB FPSTHUE\"},{\"thongTinBoPhan\":\"782\",\""
		"thongTinBoPhanText\":\"AB FPS BBN\"},{\"thongTinBoPhan\":\"783\",\"thongTinBoPhanText\":\"PBFPSESERV\"},{\"thongTinBoPhan\":\"784\",\"thongTinBoPhanText\":\"FPS CNDA\"},{\"thongTinBoPhan\":\"785\",\"thongTinBoPhanText\":\"BO FPS HN\"},{\"thongTinBoPhan\":\"786\",\"thongTinBoPhanText\":\"ABFPSBTCKB\"},{\"thongTinBoPhan\":\"787\",\"thongTinBoPhanText\":\"ABFPSHQUAN\"},{\"thongTinBoPhan\":\"788\",\"thongTinBoPhanText\":\"PrBFPSMPIT\"},{\"thongTinBoPhan\":\"789\",\"thongTinBoPhanText\":\"PB FPS APS\"}"
		",{\"thongTinBoPhan\":\"799\",\"thongTinBoPhanText\":\"Back Office + BOM\"},{\"thongTinBoPhan\":\"11012\",\"thongTinBoPhanText\":\"AB FPSTHUE\"},{\"thongTinBoPhan\":\"11013\",\"thongTinBoPhanText\":\"AB FPSTHUE\"},{\"thongTinBoPhan\":\"733\",\"thongTinBoPhanText\":\"BOM FSB\"},{\"thongTinBoPhan\":\"734\",\"thongTinBoPhanText\":\"FSB SC\"},{\"thongTinBoPhan\":\"735\",\"thongTinBoPhanText\":\"AB FSB GB\"},{\"thongTinBoPhan\":\"736\",\"thongTinBoPhanText\":\"PB FSB HN\"},{\"thongTinBoPhan\":\"737\",\""
		"thongTinBoPhanText\":\"AB FSB UL\"},{\"thongTinBoPhan\":\"738\",\"thongTinBoPhanText\":\"BO FSB\"},{\"thongTinBoPhan\":\"739\",\"thongTinBoPhanText\":\"AB FSB TEL\"},{\"thongTinBoPhan\":\"740\",\"thongTinBoPhanText\":\"PrB FSB QN\"},{\"thongTinBoPhan\":\"796\",\"thongTinBoPhanText\":\"Back Office + BOM\"},{\"thongTinBoPhan\":\"742\",\"thongTinBoPhanText\":\"PB DSVN\"},{\"thongTinBoPhan\":\"743\",\"thongTinBoPhanText\":\"FTS HCM\"},{\"thongTinBoPhan\":\"764\",\"thongTinBoPhanText\":\"GMC PMO\"},{\""
		"thongTinBoPhan\":\"765\",\"thongTinBoPhanText\":\"PB GMCeHEA\"},{\"thongTinBoPhan\":\"766\",\"thongTinBoPhanText\":\"BOM GMCHCM\"},{\"thongTinBoPhan\":\"767\",\"thongTinBoPhanText\":\"PB GMCeGOV\"},{\"thongTinBoPhan\":\"768\",\"thongTinBoPhanText\":\"PB GMC SSC\"},{\"thongTinBoPhan\":\"769\",\"thongTinBoPhanText\":\"BO GMC\"},{\"thongTinBoPhan\":\"795\",\"thongTinBoPhanText\":\"Back Office + BOM\"},{\"thongTinBoPhan\":\"11009\",\"thongTinBoPhanText\":\"Qu\\xE1\\xBB\\xB9 l\\xC6\\xB0\\xC6\\xA1ng CR"
		"\"},{\"thongTinBoPhan\":\"761\",\"thongTinBoPhanText\":\"FIS OBC HN\"},{\"thongTinBoPhan\":\"762\",\"thongTinBoPhanText\":\"FIS OBCHCM\"},{\"thongTinBoPhan\":\"700\",\"thongTinBoPhanText\":\"PB SRVBSS1\"},{\"thongTinBoPhan\":\"701\",\"thongTinBoPhanText\":\"PB SRVSSI1\"},{\"thongTinBoPhan\":\"702\",\"thongTinBoPhanText\":\"BOM SRV HN\"},{\"thongTinBoPhan\":\"703\",\"thongTinBoPhanText\":\"AB SRV ESC\"},{\"thongTinBoPhan\":\"704\",\"thongTinBoPhanText\":\"PB SRV MSC\"},{\"thongTinBoPhan\":\"705\","
		"\"thongTinBoPhanText\":\"AB SRV MNB\"},{\"thongTinBoPhan\":\"706\",\"thongTinBoPhanText\":\"BOM SRVHCM\"},{\"thongTinBoPhan\":\"707\",\"thongTinBoPhanText\":\"PB SRVBSS2\"},{\"thongTinBoPhan\":\"708\",\"thongTinBoPhanText\":\"BO SRV HCM\"},{\"thongTinBoPhan\":\"709\",\"thongTinBoPhanText\":\"PB SRVSSI2\"},{\"thongTinBoPhan\":\"710\",\"thongTinBoPhanText\":\"AB SRV CFB\"},{\"thongTinBoPhan\":\"711\",\"thongTinBoPhanText\":\"BO SRV HN\"},{\"thongTinBoPhan\":\"712\",\"thongTinBoPhanText\":\"AB SRV "
		"CBS\"},{\"thongTinBoPhan\":\"800\",\"thongTinBoPhanText\":\"Back Office + BOM\"}],\"thongTinNam\":\"2021\",\"thongTinBoPhan\":[\"716\",\"717\",\"718\",\"719\",\"720\",\"721\",\"722\",\"723\",\"724\",\"725\",\"727\",\"728\",\"729\",\"731\",\"823\",\"10911\",\"10986\",\"10987\",\"10991\",\"10992\",\"11016\",\"11017\",\"714\",\"771\",\"772\",\"773\",\"774\",\"775\",\"776\",\"777\",\"10927\",\"745\",\"746\",\"747\",\"748\",\"749\",\"750\",\"751\",\"752\",\"753\",\"754\",\"755\",\"812\",\"10993\",\""
		"10994\",\"10995\",\"10996\",\"10997\",\"10998\",\"10999\",\"11000\",\"11001\",\"11002\",\"11003\",\"11004\",\"11005\",\"11006\",\"11007\",\"11008\",\"11014\",\"11015\",\"11018\",\"801\",\"10913\",\"10943\",\"10970\",\"10971\",\"10972\",\"779\",\"780\",\"781\",\"782\",\"783\",\"784\",\"785\",\"786\",\"787\",\"788\",\"789\",\"799\",\"11012\",\"11013\",\"733\",\"734\",\"735\",\"736\",\"737\",\"738\",\"739\",\"740\",\"796\",\"742\",\"743\",\"764\",\"765\",\"766\",\"767\",\"768\",\"769\",\"795\",\""
		"11009\",\"761\",\"762\",\"700\",\"701\",\"702\",\"703\",\"704\",\"705\",\"706\",\"707\",\"708\",\"709\",\"710\",\"711\",\"712\",\"800\"]}", 
		LAST);

	web_custom_request("lnbase-cn", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-lanh-dao-DA/lnbase-cn", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-du-an", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body={\"thongTinDonVi\":[\"715\",\"713\",\"770\",\"744\",\"756\",\"778\",\"732\",\"741\",\"763\",\"760\",\"699\"],\"thongTinBoPhan\":[\"716\",\"717\",\"718\",\"719\",\"720\",\"721\",\"722\",\"723\",\"724\",\"725\",\"727\",\"728\",\"729\",\"731\",\"823\",\"10911\",\"10986\",\"10987\",\"10991\",\"10992\",\"11016\",\"11017\",\"714\",\"771\",\"772\",\"773\",\"774\",\"775\",\"776\",\"777\",\"10927\",\"745\",\"746\",\"747\",\"748\",\"749\",\"750\",\"751\",\"752\",\"753\",\"754\",\"755\",\"812\",\"10993"
		"\",\"10994\",\"10995\",\"10996\",\"10997\",\"10998\",\"10999\",\"11000\",\"11001\",\"11002\",\"11003\",\"11004\",\"11005\",\"11006\",\"11007\",\"11008\",\"11014\",\"11015\",\"11018\",\"801\",\"10913\",\"10943\",\"10970\",\"10971\",\"10972\",\"779\",\"780\",\"781\",\"782\",\"783\",\"784\",\"785\",\"786\",\"787\",\"788\",\"789\",\"799\",\"11012\",\"11013\",\"733\",\"734\",\"735\",\"736\",\"737\",\"738\",\"739\",\"740\",\"796\",\"742\",\"743\",\"764\",\"765\",\"766\",\"767\",\"768\",\"769\",\"795\","
		"\"11009\",\"761\",\"762\",\"700\",\"701\",\"702\",\"703\",\"704\",\"705\",\"706\",\"707\",\"708\",\"709\",\"710\",\"711\",\"712\",\"800\"],\"thongTinNam\":\"2021\"}", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("X-Requested-With");

	web_custom_request("don-vi", 
		"URL=https://themis.test.xplat.fpt.com.vn/bao-cao-lanh-dao-DA/don-vi", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://themis.test.xplat.fpt.com.vn/quan-ly/bcld-du-an", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"BodyBinary={\"thongTinDonVi\":[\"715\",\"713\",\"770\",\"744\",\"756\",\"778\",\"732\",\"741\",\"763\",\"760\",\"699\"],\"thongTinBoPhan\":[\"AB BNKSAL5\",\"PrB BNKVCB\",\"PB BNKFIN\",\"BOM BNK HN\",\"PrBBNKBIDV\",\"AB BNK HCM\",\"BO BNK HCM\",\"AB BNKSAL1\",\"PB BNKDATA\",\"AB BNKSAL2\",\"AB BNK CON\",\"BO BNK HN\",\"PB BNKPAY\",\"PrBBNKMPU\",\"PrBBNKSG31\",\"AB BNKSAL3\",\"PB BNK PMO\",\"Back Office + BOM\",\"AB BNK HCM\",\"AB BNKSAL3\",\"BANK TECSOL BS3\",\"BANK SOF HCM\",\"AB CA HN\",\"AB ENT "
		"ESC\",\"BOM ENT\",\"BO ENT\",\"AB ENT GSC\",\"AB ENT DSC\",\"PB ENT TSC\",\"PrB ENTSSC\",\"Back Office + BOM\",\"BOM ERP HN\",\"PB ERP ORC\",\"TH ERP\",\"AB ERP PUB\",\"ABERPPetro\",\"PBERP TECH\",\"PB ERP SAP\",\"PB ERP HCM\",\"PB ERP MBY\",\"AB ERP PRI\",\"ERPHCM\",\"Back Office + BOM\",\"ERP SAP 01\",\"ERP SAP 02\",\"ERPHCM ORC\",\"ERPHCM SAP\",\"ERPMBYIMPL\",\"ERPMBYSALE\",\"ERPORCBANK\",\"ERPORCPUB\",\"ERPPETROIM\",\"ERPPETROSL\",\"ERPSAPGLB\",\"ERPTECHORC\",\"ERPTECHSMB\",\"ERPTECHTEC\",\""
		"ERPTECHSUP\",\"ERPTECHSAP\",\"ERP PUBLIC\",\"ERP GIS&EMS\",\"ABERP Ener\",\"ERPHCM\",\"ERPHCM\",\"ERPHCM\",\"AB ERP HCM\",\"BOM ERPHCM\",\"BO ERP HCM\",\"FPSPRESALE\",\"BOM FPS HN\",\"AB FPSTHUE\",\"AB FPS BBN\",\"PBFPSESERV\",\"FPS CNDA\",\"BO FPS HN\",\"ABFPSBTCKB\",\"ABFPSHQUAN\",\"PrBFPSMPIT\",\"PB FPS APS\",\"Back Office + BOM\",\"AB FPSTHUE\",\"AB FPSTHUE\",\"BOM FSB\",\"FSB SC\",\"AB FSB GB\",\"PB FSB HN\",\"AB FSB UL\",\"BO FSB\",\"AB FSB TEL\",\"PrB FSB QN\",\"Back Office + BOM\",\"PB "
		"DSVN\",\"FTS HCM\",\"GMC PMO\",\"PB GMCeHEA\",\"BOM GMCHCM\",\"PB GMCeGOV\",\"PB GMC SSC\",\"BO GMC\",\"Back Office + BOM\",\"Qu\\xE1\\xBB\\xB9 l\\xC6\\xB0\\xC6\\xA1ng CR\",\"FIS OBC HN\",\"FIS OBCHCM\",\"PB SRVBSS1\",\"PB SRVSSI1\",\"BOM SRV HN\",\"AB SRV ESC\",\"PB SRV MSC\",\"AB SRV MNB\",\"BOM SRVHCM\",\"PB SRVBSS2\",\"BO SRV HCM\",\"PB SRVSSI2\",\"AB SRV CFB\",\"BO SRV HN\",\"AB SRV CBS\",\"Back Office + BOM\"],\"thongTinNam\":\"2021\"}", 
		LAST);

	lr_end_transaction("Trans_DuAn",LR_AUTO);

	lr_end_transaction("Trans_Baocao",LR_AUTO);

	return 0;
}
